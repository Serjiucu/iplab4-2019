public class Pacient extends Person {

  public Integer idPacient;

  public Integer CNP;

  public Integer idDoctor;

  public String personalData;


  public void Pacient() {
  }

  public void setSymptoms() {
  }

  public void updateTratamentReactins() {
  }

}