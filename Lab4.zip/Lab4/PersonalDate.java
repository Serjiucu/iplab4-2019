import java.util.Vector;

public class PersonalDate extends Pacient {

  public Integer Age;

  public Integer Height;

  public Integer Weight;

  public Integer phoneNumber;

  public String medicalHistory;

    /**
   * 
   * @element-type Medical File
   */

  public void PersonalDate() {
  }

  public void updatePersonelDate() {
  }

}