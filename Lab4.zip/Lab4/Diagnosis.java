public class Diagnosis extends Diseases {

  public String treatment;

}