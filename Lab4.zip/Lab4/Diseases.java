public class Diseases {

  public String Name;

  public String Symptoms;

}