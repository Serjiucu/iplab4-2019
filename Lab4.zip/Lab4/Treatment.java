public class Treatment extends Diagnosis {

  public String Medication;

  public String Recomandatiion;

}