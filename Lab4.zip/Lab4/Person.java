public class Person {

  public Integer Name;

  public void login() {
  }

  public void disconect() {
  }

}