public class MedicalFile {

  public Integer idPacient;

  public Integer idFile;

  public String diagnosis;

  public String symptoms;

  public String TreatmenReactions;


  public void automatchSymptoms() {
  }

}