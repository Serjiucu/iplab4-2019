import java.util.Vector;

public class Doctor extends Person {

  public Integer idDoctor;

  public Integer idPacient;

    /**
   * 
   * @element-type Pacient
   */

  public void createDiseases() {
  }

  public void updateDiseases() {
  }

  public void setDiagnosie() {
  }

  public void updateDiagnosis() {
  }

  public void approveTreatment() {
  }

  public void updateTreatment() {
  }

  public void inspectTreatmentReactin() {
  }

}